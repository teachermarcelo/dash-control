-- ============================================
-- TABELA: bnc_contracts
-- Rode este arquivo no Supabase SQL Editor antes de subir o frontend.
-- ============================================

create extension if not exists pgcrypto;

create table if not exists public.bnc_contracts (
    id uuid primary key default gen_random_uuid(),
    client_name text not null,
    cnpj text,
    contact_name text,
    phone text,
    region text,
    employee_count integer not null default 0 check (employee_count >= 0),
    monthly_value numeric(12,2) not null default 0 check (monthly_value >= 0),
    status text not null default 'active' check (status in ('active', 'paused', 'closed')),
    start_date date,
    notes text,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

alter table public.bnc_contracts enable row level security;

-- Políticas simples para o app funcionar com usuários logados.
-- Depois podemos endurecer por função: admin, manager e employee.
drop policy if exists "bnc_contracts_select_authenticated" on public.bnc_contracts;
drop policy if exists "bnc_contracts_insert_authenticated" on public.bnc_contracts;
drop policy if exists "bnc_contracts_update_authenticated" on public.bnc_contracts;
drop policy if exists "bnc_contracts_delete_authenticated" on public.bnc_contracts;

create policy "bnc_contracts_select_authenticated"
on public.bnc_contracts
for select
to authenticated
using (true);

create policy "bnc_contracts_insert_authenticated"
on public.bnc_contracts
for insert
to authenticated
with check (true);

create policy "bnc_contracts_update_authenticated"
on public.bnc_contracts
for update
to authenticated
using (true)
with check (true);

create policy "bnc_contracts_delete_authenticated"
on public.bnc_contracts
for delete
to authenticated
using (true);

-- Dados iniciais opcionais para teste
insert into public.bnc_contracts (
    client_name,
    cnpj,
    contact_name,
    phone,
    region,
    employee_count,
    monthly_value,
    status,
    start_date,
    notes
)
values
(
    'Cliente Teste BNC',
    '00.000.000/0001-00',
    'Responsável Teste',
    '(00) 00000-0000',
    'Teste',
    5,
    2500.00,
    'active',
    current_date,
    'Contrato inicial de teste.'
)
on conflict do nothing;
