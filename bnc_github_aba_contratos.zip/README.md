# Grupo BNC RH - Aba Contratos

Esta versão adiciona o primeiro módulo real do sistema: **Contratos**.

## Estrutura para GitHub Pages

```txt
index.html
js/
  config.js
  app.js
sql/
  01_bnc_contracts.sql
```

## Como instalar

1. No Supabase, abra **SQL Editor**.
2. Rode o arquivo `sql/01_bnc_contracts.sql`.
3. Suba `index.html`, `js/config.js` e `js/app.js` no GitHub.
4. Acesse o site e entre com um usuário `admin` ou `manager`.
5. Abra a aba **Contratos**.

## O que já funciona

- Listar contratos
- Buscar contratos
- Filtrar por status
- Cadastrar contrato
- Editar contrato
- Excluir contrato
- Cards de resumo: total, ativos, funcionários e receita mensal
- Dashboard inicial puxando contratos ativos

## Próximo módulo sugerido

Depois de testar e aprovar essa aba, o próximo passo é criar a aba **Funcionários**, vinculando cada funcionário a um contrato.
