// js/app.js - versão corrigida

const supabaseClient = window.bncSupabase;

if (!supabaseClient) {
    throw new Error('Cliente Supabase não encontrado. Carregue js/config.js antes de js/app.js.');
}

let currentUser = null;
let currentRole = 'employee';

function showFriendlyAuthError(error) {
    const msg = (error?.message || '').toLowerCase();

    if (msg.includes('invalid login credentials')) {
        alert('Não foi possível entrar: e-mail ou senha inválidos. Confira se o usuário existe no Supabase Auth e se a senha está correta.');
        return;
    }

    if (msg.includes('email not confirmed')) {
        alert('Não foi possível entrar: este e-mail ainda não foi confirmado no Supabase Auth.');
        return;
    }

    if (msg.includes('failed to fetch') || msg.includes('network')) {
        alert('Não foi possível conectar ao Supabase. Verifique internet, domínio autorizado/CORS e se o projeto Supabase está ativo.');
        return;
    }

    alert('Erro ao entrar: ' + (error?.message || 'erro desconhecido'));
}

async function handleLogin(e) {
    e.preventDefault();

    const email = document.getElementById('login-email').value.trim().toLowerCase();
    const password = document.getElementById('login-password').value;
    const btn = e.target.querySelector('button[type="submit"]') || e.target.querySelector('button');

    if (!email || !password) {
        alert('Preencha e-mail e senha.');
        return;
    }

    const originalText = btn.innerText;
    btn.innerText = 'Entrando...';
    btn.disabled = true;

    try {
        const { data, error } = await supabaseClient.auth.signInWithPassword({
            email,
            password
        });

        if (error) throw error;
        if (!data?.user) throw new Error('Login retornou sem usuário.');

        currentUser = data.user;

        const { data: profile, error: profileError } = await supabaseClient
            .from('bnc_profiles')
            .select('role, full_name, region')
            .eq('id', currentUser.id)
            .maybeSingle();

        // O login não deve falhar só porque o perfil ainda não existe ou está bloqueado por RLS.
        if (profileError) {
            console.warn('Perfil não carregado:', profileError.message);
        }

        currentRole = profile?.role || 'admin'; // fallback temporário para o usuário principal enxergar o painel

        document.getElementById('user-name-display').textContent = profile?.full_name || email.split('@')[0];
        document.getElementById('user-role-display').textContent = currentRole === 'admin'
            ? 'Administrador Global'
            : currentRole === 'manager'
                ? 'Gestor Regional'
                : 'Colaborador';
        document.getElementById('user-avatar').src = `https://ui-avatars.com/api/?name=${encodeURIComponent(profile?.full_name || 'Admin')}&background=ea580c&color=fff`;

        document.getElementById('login-screen').classList.add('hidden');
        document.getElementById('app-layout').classList.remove('hidden');

        renderMenu(currentRole);
        switchView(currentRole === 'admin' || currentRole === 'manager' ? 'admin-dashboard' : 'employee-dashboard');
        await loadDashboardData();
    } catch (error) {
        console.error('Erro de login:', error);
        showFriendlyAuthError(error);
    } finally {
        btn.innerText = originalText;
        btn.disabled = false;
    }
}

async function loadDashboardData() {
    try {
        const { data: contracts, error: contractsError } = await supabaseClient
            .from('bnc_contracts')
            .select('*')
            .eq('status', 'active');

        if (contractsError) console.warn('Erro ao carregar contratos:', contractsError.message);

        const totalContracts = contracts?.length || 0;
        const totalEmployees = contracts?.reduce((sum, c) => sum + (Number(c.employee_count) || 0), 0) || 0;

        const today = new Date().toISOString().split('T')[0];
        const { data: tasks, error: tasksError } = await supabaseClient
            .from('bnc_tasks')
            .select('status')
            .eq('scheduled_date', today);

        if (tasksError) console.warn('Erro ao carregar tarefas:', tasksError.message);

        const completed = tasks?.filter(t => t.status === 'completed').length || 0;

        const kpiContracts = document.getElementById('kpi-contracts');
        const kpiEmployees = document.getElementById('kpi-employees');
        const kpiTasks = document.getElementById('kpi-tasks');

        if (kpiContracts) kpiContracts.textContent = totalContracts;
        if (kpiEmployees) kpiEmployees.textContent = totalEmployees;
        if (kpiTasks) kpiTasks.textContent = `${completed} / ${tasks?.length || 0}`;

        const list = document.getElementById('contracts-list');
        if (list) {
            if (!contracts?.length) {
                list.innerHTML = '<div class="text-center text-gray-400 py-4">Nenhum contrato ativo encontrado.</div>';
                return;
            }

            list.innerHTML = contracts.map(c => `
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 bg-brand/10 text-brand rounded-lg flex items-center justify-center"><i class="fas fa-building"></i></div>
                        <div><p class="font-bold text-sm">${escapeHtml(c.client_name || 'Cliente sem nome')}</p><p class="text-xs text-gray-500">${Number(c.employee_count) || 0} funcionários</p></div>
                    </div>
                    <i class="fas fa-chevron-right text-gray-400"></i>
                </div>
            `).join('');
        }
    } catch (error) {
        console.error('Erro ao carregar dashboard:', error);
    }
}

function renderMenu(role) {
    const desktopNav = document.getElementById('desktop-menu');
    const mobileNav = document.getElementById('mobile-menu');
    if (!desktopNav || !mobileNav) return;

    desktopNav.innerHTML = '';
    mobileNav.innerHTML = '';

    const items = (role === 'admin' || role === 'manager') ? [
        { id: 'admin-dashboard', icon: 'fa-home', label: 'Início' },
        { id: 'contracts', icon: 'fa-file-contract', label: 'Contratos' },
        { id: 'employees', icon: 'fa-users', label: 'Funcionários' },
        { id: 'schedules', icon: 'fa-calendar-week', label: 'Escalas' },
        { id: 'financial', icon: 'fa-chart-line', label: 'Financeiro' },
        { id: 'settings', icon: 'fa-cog', label: 'Configurações' }
    ] : [
        { id: 'employee-dashboard', icon: 'fa-clipboard-list', label: 'Tarefas' }
    ];

    items.forEach((item, i) => {
        const d = document.createElement('button');
        d.type = 'button';
        d.className = `sidebar-item flex items-center gap-4 px-6 py-3 cursor-pointer w-full text-left ${i === 0 ? 'active' : ''}`;
        d.dataset.view = item.id;
        d.onclick = () => switchView(item.id);
        d.innerHTML = `<i class="fas ${item.icon} w-5 text-center"></i> ${item.label}`;
        desktopNav.appendChild(d);

        if (i < 4) {
            const m = document.createElement('button');
            m.type = 'button';
            m.className = `mobile-nav-item flex flex-col items-center gap-1 text-gray-400 w-1/4 ${i === 0 ? 'active text-brand' : ''}`;
            m.dataset.view = item.id;
            m.onclick = () => switchView(item.id);
            m.innerHTML = `<i class="fas ${item.icon} text-xl"></i><span class="text-[10px] font-medium">${item.label}</span>`;
            mobileNav.appendChild(m);
        }
    });
}

function switchView(id) {
    document.querySelectorAll('.view-section').forEach(e => e.classList.remove('active'));

    const target = document.getElementById(`view-${id}`);
    if (target) target.classList.add('active');

    if (id === 'contracts') {
        loadContracts();
    }

    document.querySelectorAll('.sidebar-item').forEach(e => {
        e.classList.toggle('active', e.dataset.view === id);
    });

    document.querySelectorAll('.mobile-nav-item').forEach(e => {
        const isActive = e.dataset.view === id;
        e.classList.toggle('active', isActive);
        e.classList.toggle('text-brand', isActive);
        e.classList.toggle('text-gray-400', !isActive);
    });
}

async function logout() {
    await supabaseClient.auth.signOut();
    location.reload();
}

function toggleResetForm() {
    const form = document.getElementById('reset-form');
    if (form) form.classList.toggle('hidden');
}

async function handleResetPassword() {
    const email = document.getElementById('reset-email')?.value?.trim().toLowerCase();
    if (!email) {
        alert('Digite seu e-mail para recuperar a senha.');
        return;
    }

    const { error } = await supabaseClient.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin
    });

    if (error) {
        alert('Erro ao enviar recuperação: ' + error.message);
        return;
    }

    alert('Link de recuperação enviado. Verifique seu e-mail.');
}

function escapeHtml(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function initHeaderDate() {
    const el = document.getElementById('header-date');
    if (!el) return;
    el.textContent = new Date().toLocaleDateString('pt-BR', {
        weekday: 'long',
        day: '2-digit',
        month: 'long',
        year: 'numeric'
    });
}

initHeaderDate();

window.handleLogin = handleLogin;
window.toggleResetForm = toggleResetForm;
window.handleResetPassword = handleResetPassword;
window.switchView = switchView;
window.logout = logout;


// ============================================
// MÓDULO: CONTRATOS
// ============================================
let contractsCache = [];
let contractsLoaded = false;

function moneyBR(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(Number(value) || 0);
}

function statusLabel(status) {
    const labels = {
        active: 'Ativo',
        paused: 'Pausado',
        closed: 'Encerrado'
    };
    return labels[status] || status || 'Sem status';
}

function statusClass(status) {
    if (status === 'active') return 'bg-emerald-100 text-emerald-700';
    if (status === 'paused') return 'bg-yellow-100 text-yellow-700';
    if (status === 'closed') return 'bg-red-100 text-red-700';
    return 'bg-gray-100 text-gray-700';
}

async function loadContracts(force = false) {
    if (contractsLoaded && !force) {
        renderContractsTable(contractsCache);
        return;
    }

    const tbody = document.getElementById('contracts-table-body');
    if (tbody) {
        tbody.innerHTML = '<tr><td colspan="7" class="px-4 py-8 text-center text-gray-400">Carregando contratos...</td></tr>';
    }

    const { data, error } = await supabaseClient
        .from('bnc_contracts')
        .select('*')
        .order('created_at', { ascending: false });

    if (error) {
        console.error('Erro ao carregar contratos:', error);
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="7" class="px-4 py-8 text-center text-red-500">Erro ao carregar contratos: ${escapeHtml(error.message)}</td></tr>`;
        }
        return;
    }

    contractsCache = data || [];
    contractsLoaded = true;
    renderContractsTable(contractsCache);
}

function filterContracts() {
    const search = document.getElementById('contracts-search')?.value?.toLowerCase().trim() || '';
    const status = document.getElementById('contracts-status-filter')?.value || 'all';

    const filtered = contractsCache.filter(contract => {
        const text = [
            contract.client_name,
            contract.cnpj,
            contract.contact_name,
            contract.region,
            contract.phone,
            contract.notes
        ].join(' ').toLowerCase();

        const matchesSearch = !search || text.includes(search);
        const matchesStatus = status === 'all' || contract.status === status;
        return matchesSearch && matchesStatus;
    });

    renderContractsTable(filtered);
}

function renderContractsTable(contracts) {
    const tbody = document.getElementById('contracts-table-body');
    if (!tbody) return;

    updateContractsSummary(contractsCache);

    if (!contracts.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="px-4 py-8 text-center text-gray-400">Nenhum contrato encontrado.</td></tr>';
        return;
    }

    tbody.innerHTML = contracts.map(contract => `
        <tr class="hover:bg-gray-50">
            <td class="px-4 py-4">
                <p class="font-bold text-gray-800">${escapeHtml(contract.client_name || '-')}</p>
                <p class="text-xs text-gray-500">${escapeHtml(contract.cnpj || 'CNPJ não informado')}</p>
            </td>
            <td class="px-4 py-4">
                <p class="text-gray-700">${escapeHtml(contract.contact_name || '-')}</p>
                <p class="text-xs text-gray-500">${escapeHtml(contract.phone || '')}</p>
            </td>
            <td class="px-4 py-4 text-gray-600">${escapeHtml(contract.region || '-')}</td>
            <td class="px-4 py-4 text-center font-bold">${Number(contract.employee_count) || 0}</td>
            <td class="px-4 py-4 text-right font-bold text-gray-800">${moneyBR(contract.monthly_value)}</td>
            <td class="px-4 py-4 text-center">
                <span class="px-3 py-1 rounded-full text-xs font-bold ${statusClass(contract.status)}">${statusLabel(contract.status)}</span>
            </td>
            <td class="px-4 py-4 text-right whitespace-nowrap">
                <button onclick="editContract('${contract.id}')" class="text-blue-600 hover:text-blue-800 px-2" title="Editar"><i class="fas fa-edit"></i></button>
                <button onclick="deleteContract('${contract.id}')" class="text-red-500 hover:text-red-700 px-2" title="Excluir"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `).join('');
}

function updateContractsSummary(contracts) {
    const total = contracts.length;
    const active = contracts.filter(c => c.status === 'active').length;
    const employees = contracts.reduce((sum, c) => sum + (Number(c.employee_count) || 0), 0);
    const revenue = contracts
        .filter(c => c.status === 'active')
        .reduce((sum, c) => sum + (Number(c.monthly_value) || 0), 0);

    const totalEl = document.getElementById('contracts-total');
    const activeEl = document.getElementById('contracts-active');
    const employeesEl = document.getElementById('contracts-employees');
    const revenueEl = document.getElementById('contracts-revenue');

    if (totalEl) totalEl.textContent = total;
    if (activeEl) activeEl.textContent = active;
    if (employeesEl) employeesEl.textContent = employees;
    if (revenueEl) revenueEl.textContent = moneyBR(revenue);
}

function openContractModal(contract = null) {
    const modal = document.getElementById('contract-modal');
    const form = document.getElementById('contract-form');
    if (!modal || !form) return;

    form.reset();
    document.getElementById('contract-id').value = contract?.id || '';
    document.getElementById('contract-modal-title').textContent = contract ? 'Editar Contrato' : 'Novo Contrato';
    document.getElementById('contract-client-name').value = contract?.client_name || '';
    document.getElementById('contract-cnpj').value = contract?.cnpj || '';
    document.getElementById('contract-status').value = contract?.status || 'active';
    document.getElementById('contract-contact-name').value = contract?.contact_name || '';
    document.getElementById('contract-phone').value = contract?.phone || '';
    document.getElementById('contract-region').value = contract?.region || '';
    document.getElementById('contract-employee-count').value = contract?.employee_count ?? 0;
    document.getElementById('contract-monthly-value').value = contract?.monthly_value ?? 0;
    document.getElementById('contract-start-date').value = contract?.start_date || '';
    document.getElementById('contract-notes').value = contract?.notes || '';

    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function closeContractModal() {
    const modal = document.getElementById('contract-modal');
    if (!modal) return;
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

function getContractPayload() {
    return {
        client_name: document.getElementById('contract-client-name').value.trim(),
        cnpj: document.getElementById('contract-cnpj').value.trim() || null,
        status: document.getElementById('contract-status').value,
        contact_name: document.getElementById('contract-contact-name').value.trim() || null,
        phone: document.getElementById('contract-phone').value.trim() || null,
        region: document.getElementById('contract-region').value.trim() || null,
        employee_count: Number(document.getElementById('contract-employee-count').value) || 0,
        monthly_value: Number(document.getElementById('contract-monthly-value').value) || 0,
        start_date: document.getElementById('contract-start-date').value || null,
        notes: document.getElementById('contract-notes').value.trim() || null,
        updated_at: new Date().toISOString()
    };
}

async function saveContract(event) {
    event.preventDefault();

    const id = document.getElementById('contract-id').value;
    const payload = getContractPayload();

    if (!payload.client_name) {
        alert('Informe o nome do cliente.');
        return;
    }

    let response;
    if (id) {
        response = await supabaseClient
            .from('bnc_contracts')
            .update(payload)
            .eq('id', id);
    } else {
        response = await supabaseClient
            .from('bnc_contracts')
            .insert(payload);
    }

    if (response.error) {
        alert('Erro ao salvar contrato: ' + response.error.message);
        return;
    }

    closeContractModal();
    contractsLoaded = false;
    await loadContracts(true);
    await loadDashboardData();
    alert(id ? 'Contrato atualizado com sucesso.' : 'Contrato cadastrado com sucesso.');
}

function editContract(id) {
    const contract = contractsCache.find(c => c.id === id);
    if (!contract) {
        alert('Contrato não encontrado.');
        return;
    }
    openContractModal(contract);
}

async function deleteContract(id) {
    const contract = contractsCache.find(c => c.id === id);
    const name = contract?.client_name || 'este contrato';

    if (!confirm(`Tem certeza que deseja excluir ${name}?`)) return;

    const { error } = await supabaseClient
        .from('bnc_contracts')
        .delete()
        .eq('id', id);

    if (error) {
        alert('Erro ao excluir contrato: ' + error.message);
        return;
    }

    contractsLoaded = false;
    await loadContracts(true);
    await loadDashboardData();
    alert('Contrato excluído com sucesso.');
}

window.openContractModal = openContractModal;
window.closeContractModal = closeContractModal;
window.saveContract = saveContract;
window.editContract = editContract;
window.deleteContract = deleteContract;
window.filterContracts = filterContracts;
